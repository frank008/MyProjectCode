package com.dfdk.common.utils.parseUtils.parsekmz;


import de.micromata.opengis.kml.v_2_2_0.*;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @description: KML文件解析：先获取kml文件的根节点，依次遍历当前节点的子节点的信息，
 * 如果遇到节点属于Folder、Document则继续解析其子节点；反之则解析PlaceMark节点（主要解析LineString、Point、Polygon）。
 * @author: frank
 * @create: 2022-08-09 12:00
 **/
public class ParsingKmlUtil {
    public static  Node dirNode = new Node(); //数据容器
    public static ArrayList<Node> nodes = new ArrayList<>(); //所有点坐标
    public static ArrayList<PointItem> pointItemList = new ArrayList<>(); //所有点详细坐标 目录集合
    public static Map<String, PointItem> lineItemMap = new HashMap<>(); // 线路坐标集合
    public static ArrayList<String> fimsAreaList = new ArrayList<>(); //区域名称

    public static ArrayList<NewKmlObj> newKmlPonitsObjsList = new ArrayList<>(); //新遍历方式 点对象集合
    public static Map<String, NewKmlObj> newKmlLinesObjsMap = new HashMap<>(); //新遍历方式 线路对象集合

    /**
     * 保存kml数据到临时表
     *
     * @param file 上传的文件实体
     * @return 自定义的KML文件实体
     */
    public static void parseKmlToPointItem(File file) {
        Kml kml = Kml.unmarshal(file);
        Feature feature = kml.getFeature();

        parseFeatureKml(feature); //主要方法开始解析
        getAllPoints(dirNode); //获取坐标 目录 结构
        PointParseItem(nodes); //坐标点解析

        System.out.println("kml文件解析完成!");
    }

    /**提取所有的 点坐标对象*/
    public static void getAllPoints(Node node) {
        if (null != node.placemark) {
            nodes.add(node);
        }
        if (null != node.childrenNodes) {
            List<Node> childrenNodes = node.childrenNodes;
            if (childrenNodes.size() > 0) {
                for (Node childrenNode : childrenNodes) {
                    getAllPoints(childrenNode);
                }
            }
        }
    }

    /**解析出 kml 数据*/
    private static void parseFeatureKmlTwo(Feature feature) {

        long startTime = System.currentTimeMillis();
        if (feature instanceof Folder) { //0层
            String dirName = feature.getName();

            List<Feature> featureList1 = ((Folder) feature).getFeature();
            for (Feature feature1 : featureList1) {
                if (feature1 instanceof Folder) { //1层
                    String dirName1 = feature1.getName();

                    List<Feature> featureList2 = ((Folder) feature1).getFeature();
                    for (Feature feature2 : featureList2) {
                        if (feature2 instanceof Folder) { //2层
                            String dirName2 = feature2.getName();

                            List<Feature> featureList3 = ((Folder) feature2).getFeature();
                            for (Feature feature3 : featureList3) {
                                if (feature3 instanceof Folder) { //3层
                                    String dirName3 = feature3.getName();

                                    List<Feature> featureList4 = ((Folder) feature3).getFeature();

                                    for (Feature feature4 : featureList4) {
                                        if (feature4 instanceof Folder) { //4层
                                            String dirName4 = feature4.getName();

                                            List<Feature> featureList5 = ((Folder) feature4).getFeature();

                                            for (Feature feature5 : featureList5) {
                                                if (feature5 instanceof Folder) { //5层
                                                    String dirName5 = feature5.getName();

                                                    List<Feature> featureList6 = ((Folder) feature5).getFeature();

                                                    for (Feature feature6 : featureList6) {
                                                        if (feature6 instanceof Folder) { //6层
                                                            String dirName6 = feature6.getName();

                                                            List<Feature> featureList7 = ((Folder) feature6).getFeature();

                                                            for (Feature feature7 : featureList7) {

                                                                if (feature7 instanceof Folder) { //7层
                                                                    String dirName7 = feature7.getName();
                                                                    List<Feature> featureList8 = ((Folder) feature7).getFeature();

                                                                    for (Feature feature8 : featureList8) {

                                                                        if (feature8 instanceof Folder) { //8层
                                                                            String dirName8 = feature8.getName();
                                                                            List<Feature> featureList9 = ((Folder) feature8).getFeature();

                                                                            for (Feature feature9 : featureList9) {
                                                                                if (feature9 instanceof Folder) { //9层
                                                                                    String dirName9 = feature9.getName();
                                                                                    List<Feature> featureList10 = ((Folder) feature9).getFeature();

                                                                                    for (Feature feature10 : featureList10) {
                                                                                        if (feature10 instanceof Folder) { //10层
                                                                                            String dirName10 = feature10.getName();
                                                                                            List<Feature> featureList11 = ((Folder) feature10).getFeature();

                                                                                            for (Feature feature11 : featureList11) {
                                                                                                int index = featureList11.indexOf(feature11);
                                                                                                if (feature11 instanceof Placemark) {
                                                                                                    String tempDir = dirName + "," + dirName1 + "," + dirName2 + "," + dirName3 + "," + dirName4 + "," + dirName5 + "," + dirName6 + "," + dirName7 + "," + dirName8 + "," + dirName9 + "," + dirName10;
                                                                                                    NewKmlObj newKmlObj = setItemValues(tempDir, feature11);
                                                                                                    newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                                                                                    newKmlObj.orderNo=index; //设置序号
                                                                                                    newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                                                                                }
                                                                                            }
                                                                                        } else {
                                                                                            if (feature10 instanceof Placemark) {
                                                                                                int index = featureList10.indexOf(feature10);
                                                                                                String tempDir = dirName + "," + dirName1 + "," + dirName2 + "," + dirName3 + "," + dirName4 + "," + dirName5 + "," + dirName6 + "," + dirName7 + "," + dirName8 + "," + dirName9;
                                                                                                NewKmlObj newKmlObj = setItemValues(tempDir, feature10);
                                                                                                newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                                                                                newKmlObj.orderNo=index; //设置序号
                                                                                                newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                } else {
                                                                                    if (feature9 instanceof Placemark) {
                                                                                        int index = featureList9.indexOf(feature9);
                                                                                        String tempDir = dirName + "," + dirName1 + "," + dirName2 + "," + dirName3 + "," + dirName4 + "," + dirName5 + "," + dirName6 + "," + dirName7 + "," + dirName8;
                                                                                        NewKmlObj newKmlObj = setItemValues(tempDir, feature9);
                                                                                        newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                                                                        newKmlObj.orderNo=index; //设置序号
                                                                                        newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                                                                    }
                                                                                }

                                                                            }
                                                                        } else {
                                                                            if (feature8 instanceof Placemark) {
                                                                                int index = featureList8.indexOf(feature8);
                                                                                String tempDir = dirName + "," + dirName1 + "," + dirName2 + "," + dirName3 + "," + dirName4 + "," + dirName5 + "," + dirName6 + "," + dirName7;
                                                                                NewKmlObj newKmlObj = setItemValues(tempDir, feature8);
                                                                                newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                                                                newKmlObj.orderNo=index; //设置序号
                                                                                newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                                                            }
                                                                        }
                                                                    }
                                                                } else {
                                                                    if (feature7 instanceof Placemark) {
                                                                        int index = featureList7.indexOf(feature7);
                                                                        String tempDir = dirName + "," + dirName1 + "," + dirName2 + "," + dirName3 + "," + dirName4 + "," + dirName5 + "," + dirName6;
                                                                        NewKmlObj newKmlObj = setItemValues(tempDir, feature7);
                                                                        newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                                                        newKmlObj.orderNo=index; //设置序号
                                                                        newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                                                    }
                                                                }

                                                            }
                                                        } else {
                                                            if (feature6 instanceof Placemark) {
                                                                int index = featureList6.indexOf(feature6);
                                                                String tempDir = dirName + "," + dirName1 + "," + dirName2 + "," + dirName3 + "," + dirName4 + "," + dirName5;
                                                                NewKmlObj newKmlObj = setItemValues(tempDir, feature6);
                                                                newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                                                newKmlObj.orderNo=index; //设置序号
                                                                newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if (feature5 instanceof Placemark) {
                                                        int index = featureList5.indexOf(feature5);
                                                        String tempDir = dirName + "," + dirName1 + "," + dirName2 + "," + dirName3 + "," + dirName4;
                                                        NewKmlObj newKmlObj = setItemValues(tempDir, feature5);
                                                        newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                                        newKmlObj.orderNo=index; //设置序号
                                                        newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                                    }
                                                }
                                            }
                                        } else {
                                            if (feature4 instanceof Placemark) {
                                                int index = featureList4.indexOf(feature4);
                                                String tempDir = dirName + "," + dirName1 + "," + dirName2 + "," + dirName3;
                                                NewKmlObj newKmlObj = setItemValues(tempDir, feature4);
                                                newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                                newKmlObj.orderNo=index; //设置序号
                                                newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                            }
                                        }
                                    }
                                } else {
                                    if (feature3 instanceof Placemark) {
                                        int index = featureList3.indexOf(feature3);
                                        String tempDir = dirName + "," + dirName1 + "," + dirName2;
                                        NewKmlObj newKmlObj = setItemValues(tempDir, feature3);
                                        newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                        newKmlObj.orderNo=index; //设置序号
                                        newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                                    }
                                }
                            }
                        } else {
                            if (feature2 instanceof Placemark) {
                                int index = featureList2.indexOf(feature2);
                                String tempDir = dirName + "," + dirName1;
                                NewKmlObj newKmlObj = setItemValues(tempDir, feature2);
                                newKmlObj.lineName=findLineName(tempDir); //设置线路名
                                newKmlObj.orderNo=index; //设置序号
                                newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                            }
                        }
                    }


                } else {
                    if (feature1 instanceof Placemark) {

                        int index = featureList1.indexOf(feature1);

                        NewKmlObj newKmlObj = setItemValues(dirName, feature1);
                        newKmlObj.lineName=findLineName(dirName); //设置线路名
                        newKmlObj.orderNo=index;
                        newKmlPonitsObjsList.add(newKmlObj); //点对象集合
                    }
                }


            }


        } else {
            if (feature instanceof Placemark) {
                String tempDir = feature.getName();

                NewKmlObj newKmlObj = setItemValues(tempDir, feature);
                newKmlObj.lineName=findLineName(tempDir); //设置线路名
                newKmlPonitsObjsList.add(newKmlObj); //点对象集合
            }
        }
        long endTime = System.currentTimeMillis();

        System.out.println("kml解析耗时：" + (endTime - startTime));


    }

    private static void PointParseItem(ArrayList<Node> nodes) {

        for (Node node : nodes) {

            Placemark placemark = node.placemark;

            PointItem pointItem = new PointItem();
            pointItem.name = node.name; //设置名称
            pointItem.des = placemark.getDescription(); //设置描述
            pointItem.parentName = node.parentNode.name; //父名称
            //设置目录
            Node tempNode = node;
            while (null != tempNode.parentNode) {
                tempNode = tempNode.parentNode;
                String name = tempNode.name;
                if ("根节点".equalsIgnoreCase(name) || "线路路径".equalsIgnoreCase(name)) {
                    continue;
                }
                pointItem.dirList.add(name);
            }
            //倒排序目录
            pointItem.setDirListOrder();

            if (!fimsAreaList.contains(pointItem.dirList.get(0))) {
                fimsAreaList.add(pointItem.dirList.get(0));
            }

            //设置经度,纬度,海拔,线路坐标
            parseGeometry(pointItem,placemark.getGeometry());
            //添加到 List
            if (pointItem.isLine) {
                lineItemMap.put(pointItem.parentName, pointItem);
            } else {
                pointItemList.add(pointItem);
            }
        }

    }

    /**设置 node 节点信息*/
    public static NewKmlObj setItemValues(String tempDir, Feature feature) {
        NewKmlObj kmlObj = new NewKmlObj();
        //设置目录
        kmlObj.dirStr = tempDir; //目录
        //设置名称
        kmlObj.name = feature.getName();
        //设置描述
        kmlObj.des = feature.getDescription();
        //设置坐标
        parseNewGeometry(((Placemark) feature).getGeometry(), kmlObj);
        return kmlObj;

    }

    /**判断线路名称*/
    private static String findLineName(String dirStr) {
        String destName="";
        if(!dirStr.contains(",")){
            return dirStr;
        }
        String[] split = dirStr.split(",");
        //倒过去找
        int length = split.length-1;
        for (int i = length; i>0 ; i--) {
            String tempStr = split[i];
            if(tempStr.contains("线")&&tempStr.contains("_")||tempStr.toLowerCase().contains("kml")||tempStr.toLowerCase().contains("kmz")){
                destName=tempStr;
                break;
            }
        }
        return destName;
    }

    /**解析出目录  坐标  描述  名称*/
    private static void parseFeatureKml(Feature feature) {
        if (feature != null) {
            //判断根节点是否为Document
            if (feature instanceof Document) {
                List<Feature> featureList = ((Document) feature).getFeature();
                //遍历已获取的节点信息(节点信息为List)，将list使用forEach进行遍历（同for、while）
                featureList.forEach(documentFeature -> {
                            //判断遍历节点是否为PlaceMark，否则迭代解析
                            if (documentFeature instanceof Placemark) {
                                System.out.println("PlaceMark节点");
                            } else {
                                parseFeatureKmlTwo(documentFeature);
                            }
                        }
                );
            } else if (feature instanceof Folder) {
                //生成目录
                String featureName = feature.getName();
                String phoneNumber = feature.getPhoneNumber(); //携带序号


                //名称 序号对比是否相同
                Node node = new Node();
                node.name = featureName;
                if (null != phoneNumber && phoneNumber.contains("HZ自设值")) {
                    int orderNo = Integer.parseInt(phoneNumber.split("HZ自设值-")[1]);
                    node.orderNo = orderNo;
                }


                dirNode.findNode(dirNode, node);
                dirNode.addChildrenNode(dirNode.currentNode, node);

                List<Feature> featureList = ((Folder) feature).getFeature();

                //添加目录
                for (int i = 0; i < featureList.size(); i++) {
                    Feature documentFeature = featureList.get(i);
                    String name = documentFeature.getName();

                    if ("110kV泵湖线".equalsIgnoreCase(name)) {
                        System.out.println("暂停");
                    }
                    dirNode.findNode(dirNode, node); //设置为当前节点
                    Node nodeTwo = new Node();
                    nodeTwo.name = name;
                    nodeTwo.orderNo = i;
                    dirNode.findNode(dirNode.currentNode, nodeTwo); //找寻节点
                    dirNode.addChildrenNode(dirNode.currentNode, nodeTwo);
                }

                for (int i = 0; i < featureList.size(); i++) {
                    Feature documentFeature = featureList.get(i);
                    String name = documentFeature.getName();
                    Node nodeThree = new Node();
                    nodeThree.name = name;
                    nodeThree.orderNo = i;

                    if (documentFeature instanceof Placemark) {
                        dirNode.addNodePonit(dirNode.currentNode, nodeThree, (Placemark) documentFeature);
                    } else {
                        documentFeature.setPhoneNumber("HZ自设值-" + i); //设置序号
                        parseFeatureKml(documentFeature);
                    }
                }
            }
        }
    }

    /** 解析PlaceMark 坐标节点下的信息*/
    private static void parseGeometry(PointItem pointItem,Geometry geometry) {

        if (geometry != null) {
            if (geometry instanceof Polygon) {
                Polygon polygon = (Polygon) geometry;
                Boundary outerBoundaryIs = polygon.getOuterBoundaryIs();
                if (outerBoundaryIs != null) {
                    LinearRing linearRing = outerBoundaryIs.getLinearRing();
                    if (linearRing != null) {
                        List<Coordinate> coordinates = linearRing.getCoordinates();
                        if (coordinates != null) {
                            outerBoundaryIs = ((Polygon) geometry).getOuterBoundaryIs();
                            List<Coordinate> coordinates1 = outerBoundaryIs.getLinearRing().getCoordinates();
                            pointItem.pointsList = coordinates1;
                            pointItem.isLine = true;
                        }
                    }
                }
            } else if (geometry instanceof LineString) {
                LineString lineString = (LineString) geometry;
                List<Coordinate> coordinates = lineString.getCoordinates();
                if (coordinates != null) {
                    coordinates = ((LineString) geometry).getCoordinates();
                    pointItem.pointsList = coordinates;
                    pointItem.isLine = true;
                }
            } else if (geometry instanceof Point) {
                Point point = (Point) geometry;
                List<Coordinate> coordinates = point.getCoordinates();
                if (coordinates != null) {
                    coordinates = ((Point) geometry).getCoordinates();
                    pointItem.pointsList = coordinates;
                }
            } else if (geometry instanceof MultiGeometry) {
                List<Geometry> geometries = ((MultiGeometry) geometry).getGeometry();
                for (Geometry geometryToMult : geometries) {
                    Boundary outerBoundaryIs;
                    List<Coordinate> coordinates;
                    if (geometryToMult instanceof Point) {
                        coordinates = ((Point) geometryToMult).getCoordinates();
                        pointItem.pointsList = coordinates;
                    } else if (geometryToMult instanceof LineString) {
                        coordinates = ((LineString) geometryToMult).getCoordinates();
                        pointItem.pointsList = coordinates;
                    } else if (geometryToMult instanceof Polygon) {
                        outerBoundaryIs = ((Polygon) geometryToMult).getOuterBoundaryIs();
                        List<Coordinate> coordinates1 = outerBoundaryIs.getLinearRing().getCoordinates();
                        pointItem.pointsList = coordinates1;
                        pointItem.isLine = true;
                    }
                }
            }
        }
    }

    private static void parseNewGeometry(Geometry geometry, NewKmlObj kmlObj) {
        if (geometry != null) {
            if (geometry instanceof Polygon) {
                Polygon polygon = (Polygon) geometry;
                Boundary outerBoundaryIs = polygon.getOuterBoundaryIs();
                if (outerBoundaryIs != null) {
                    LinearRing linearRing = outerBoundaryIs.getLinearRing();
                    if (linearRing != null) {
                        List<Coordinate> coordinates = linearRing.getCoordinates();
                        if (coordinates != null) {
                            outerBoundaryIs = ((Polygon) geometry).getOuterBoundaryIs();
                            List<Coordinate> coordinates1 = outerBoundaryIs.getLinearRing().getCoordinates();
                            kmlObj.pointsList = coordinates1;
                            kmlObj.isLine = true;
                        }
                    }
                }
            } else if (geometry instanceof LineString) {
                LineString lineString = (LineString) geometry;
                List<Coordinate> coordinates = lineString.getCoordinates();
                if (coordinates != null) {
                    coordinates = ((LineString) geometry).getCoordinates();
                    kmlObj.pointsList = coordinates;
                    kmlObj.isLine = true;
                }
            } else if (geometry instanceof Point) {
                Point point = (Point) geometry;
                List<Coordinate> coordinates = point.getCoordinates();
                if (coordinates != null) {
                    coordinates = ((Point) geometry).getCoordinates();
                    kmlObj.pointsList = coordinates;
                }
            } else if (geometry instanceof MultiGeometry) {
                List<Geometry> geometries = ((MultiGeometry) geometry).getGeometry();
                for (Geometry geometryToMult : geometries) {
                    Boundary outerBoundaryIs;
                    List<Coordinate> coordinates;
                    if (geometryToMult instanceof Point) {
                        coordinates = ((Point) geometryToMult).getCoordinates();
                        kmlObj.pointsList = coordinates;
                    } else if (geometryToMult instanceof LineString) {
                        coordinates = ((LineString) geometryToMult).getCoordinates();
                        kmlObj.pointsList = coordinates;
                    } else if (geometryToMult instanceof Polygon) {
                        outerBoundaryIs = ((Polygon) geometryToMult).getOuterBoundaryIs();
                        List<Coordinate> coordinates1 = outerBoundaryIs.getLinearRing().getCoordinates();
                        kmlObj.pointsList = coordinates1;
                        kmlObj.isLine = true;
                    }
                }
            }
        }
    }


}
