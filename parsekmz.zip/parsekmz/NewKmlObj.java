package com.dfdk.common.utils.parseUtils.parsekmz;

import de.micromata.opengis.kml.v_2_2_0.Coordinate;

import java.util.ArrayList;
import java.util.List;

public class NewKmlObj {

    public String dirStr; //目录数组
    public String name; //名称
    public String des; //描述

    public String lineName; //线路名称
    public int orderNo; //序号

    public boolean isLine=false; //是否是线路

    public List<Coordinate> pointsList = new ArrayList<>(); //线路列表 坐标 ，Coordinate 坐标对象


    @Override
    public String toString() {
        return "newKmlObj{" +
                "dirStr='" + dirStr + '\'' +
                ", name='" + name + '\'' +
                ", des='" + des + '\'' +
                ", isLine=" + isLine +
                ", pointsList=" + pointsList +
                '}';
    }
}
