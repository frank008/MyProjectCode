package com.dfdk.common.utils.parseUtils.parsekmz.db;

import com.dfdk.common.utils.parseUtils.CoordinateTransform;
import com.dfdk.common.utils.parseUtils.parsekmz.NewKmlObj;
import de.micromata.opengis.kml.v_2_2_0.Coordinate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/*
 * weimingfa
 * 2022-07-26
 * */
@Slf4j
@Component
public class DbServicesUtils {

    @Autowired
    public DButils dButils;
    public Connection connection;

    public HashMap<String, Object> addDataMap = new HashMap<>();
    //区域ID
    public HashMap<String, Object> areaIdMap = new HashMap<>();
    //线路ID
    public HashMap<String, Object> lineIdMap = new HashMap<>();

    //区域名称 电压等级
    public HashMap<String, Map<String, String>> areaVoMap = new HashMap<>();

    /**保持有序*/
    public AtomicInteger atomicInteger = new AtomicInteger(1);
    public AtomicInteger atomicIntegerDB = new AtomicInteger(1);


    /**解析 kml数据 准备插入数据库*/
    public void parseDataNew(ArrayList<NewKmlObj> newKmlPonitsObjsList, Map<String, NewKmlObj> newKmlLinesObjsMap) {
        connection = dButils.getConnection();
        setAreaIdMap(); //查询区域ID
        setLineIdMap(); //查询线路ID

        long startTime = System.currentTimeMillis();
        ArrayList<HashMap<String, Object>> mainList = new ArrayList<>();
        for (int i = 0; i < newKmlPonitsObjsList.size(); i++) {
            NewKmlObj newKmlObj = newKmlPonitsObjsList.get(i);

            //获取目录  设置区域,电压等级
            String areaName = ""; //区域名称
            String voltage = ""; //电压的等级

            String dirStr = newKmlObj.dirStr;
            Map<String, String> stringMap = areaVoMap.get(dirStr);
            if (null == stringMap) {
                setAreavoltage(dirStr);
            }
            stringMap = areaVoMap.get(dirStr);

            for (Map.Entry<String, String> entry : stringMap.entrySet()) {
                areaName = entry.getKey();
                voltage = entry.getValue();

                if (!voltage.equalsIgnoreCase("") && null != voltage) {
                    addDataMap.put("voltage", voltage); //电压等级
                }
            }

            //areaId 不存在
            if (!areaName.equalsIgnoreCase("") && null == areaIdMap.get(areaName)) {
                addDataMap.put("area_id", getAreaId(areaName)); //区域ID
                addDataMap.put("voltage", voltage); //电压等级
                addDataMap.put("area_name", areaName); //区域
                areaIdMap.put(areaName, addDataMap.get("area_id")); //区域名称，区域ID
            } else {
                addDataMap.put("area_id", areaIdMap.get(areaName)); //区域ID
                addDataMap.put("voltage", voltage); //电压等级
                addDataMap.put("area_name", areaName); //区域
            }

            //线路解析  有些没有线路坐标
            String lineName = newKmlObj.lineName;
            NewKmlObj newKmlObj1 = newKmlLinesObjsMap.get(lineName);
            if (null == newKmlObj1 && null == lineIdMap.get(lineName)) {
                newKmlObj1 = new NewKmlObj();
                newKmlObj1.name = lineName;
            }

            if (null != newKmlObj1) {
                if (null == lineIdMap.get(lineName)) {
                    String lineId = getLineId(lineName);
                    addDataMap.put("line_id", lineId); //线路ID
                    addDataMap.put("obj_id", lineId); //线路ID
                    addDataMap.put("line_name", lineName); //线路名称
                    lineIdMap.put(lineName, lineId); //线路名称,线路ID
                    try {
                        if (lineName.contains("惠州_")) {
                            lineName = lineName.split("惠州_")[1];
                        }
                        if (lineName.contains(".")) {
                            lineName = lineName.split("\\.")[0];
                        }
                        addDataMap.put("short_name", lineName); //线路简称
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    addDataMap.put("coordinate_type", 0); //坐标类型
                }
            }

            String pole_name = newKmlObj.name; //杆塔名称
            String des = newKmlObj.des; //杆塔描述
            addDataMap.put("pole_id", getUUID());
            addDataMap.put("fp_name", pole_name);
            addDataMap.put("depict", des);
            addDataMap.put("orderNo", newKmlObj.orderNo);

            if (newKmlObj.isLine) {
                //处理线坐标
                List<Coordinate> pointsList = newKmlObj.pointsList;
                StringBuilder gps = new StringBuilder();
                //解析线路坐标
                for (Coordinate coordinate : pointsList) {
                    double longitude = coordinate.getLongitude();
                    double latitude = coordinate.getLatitude();
                    double[] wgs84ToBD09 = CoordinateTransform.transformWGS84ToBD09(longitude, latitude);
                    String coordinateStr = wgs84ToBD09[0] + "_" + wgs84ToBD09[1]; //经度_纬度
                    if (gps.toString().equalsIgnoreCase("")) {
                        gps = new StringBuilder(coordinateStr);
                    } else {
                        gps.append(",").append(coordinateStr);
                    }
                }
                addDataMap.put("line_coordinates", gps.toString()); //坐标列表
                //是否是线路坐标
                if (newKmlObj.isLine) {
                    addDataMap.put("is_line", 1); //坐标列表
                }
            } else {
                //清空线路坐标
                addDataMap.put("is_line", 0);
                addDataMap.put("line_coordinates", ""); //坐标列表

                List<Coordinate> pointsList = newKmlObj.pointsList;
                if (pointsList.size() == 0) {
                    System.out.println("坐标为空!" + newKmlObj);
                    continue;
                }
                double longitude = pointsList.get(0).getLongitude();
                double latitude = pointsList.get(0).getLatitude();
                double[] wgs84ToBD09 = CoordinateTransform.transformWGS84ToBD09(longitude, latitude);

                addDataMap.put("baidu_lng", wgs84ToBD09[0]);
                addDataMap.put("baidu_lat", wgs84ToBD09[1]);
            }

            //方便批量查询
            HashMap<String, Object> temMap = new HashMap<>();
            for (Map.Entry<String, Object> entry : addDataMap.entrySet()) {
                temMap.put(entry.getKey(), entry.getValue());
            }
            mainList.add(temMap);
        }

        long endTime = System.currentTimeMillis();
        log.info("解析完成! 耗时：" + (endTime - startTime));

        //插入数据库
        insertData(mainList);
        log.info("kml数据插入数据库完成!");

        try {
            connection.close();
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * 解析 组装数据 插入数据库
     */
    public void insertData(ArrayList<HashMap<String, Object>> mainList) {

        ArrayList<String> areaListAll = new ArrayList<>();
        ArrayList<String> lineListAll = new ArrayList<>();
        ArrayList<String> lineGpsListAll = new ArrayList<>();


        StringBuilder fimsAreaSqlValues = new StringBuilder();
        StringBuilder fimsLineSqlValues = new StringBuilder();
        StringBuilder fimsGpsSqlValues = new StringBuilder();
        StringBuilder fimsPoleSqlValues = new StringBuilder();
        StringBuilder fimsLinePoleSqlValues = new StringBuilder();


        // 1000条插入一次
        int size = mainList.size();
        for (int i = 0; i < size; i++) {

            HashMap<String, Object> objectHashMap = mainList.get(i); //对象数据
            Object areaId = objectHashMap.get("area_id");
            Object areaName = objectHashMap.get("area_name");
            Object voltage = objectHashMap.get("voltage");

            Object lineId = objectHashMap.get("line_id");
            Object objId = objectHashMap.get("obj_id");

            Object lineName = objectHashMap.get("line_name");
            Object shortName = objectHashMap.get("short_name");
            Object coordinateType = objectHashMap.get("coordinate_type");

            Object gps = objectHashMap.get("gps");

            Object poleId = objectHashMap.get("pole_id");
            Object fpName = objectHashMap.get("fp_name");
            Object depict = objectHashMap.get("depict");
            Object baiduLng = objectHashMap.get("baidu_lng");
            Object baiduLat = objectHashMap.get("baidu_lat");

            Object isLine = objectHashMap.get("is_line");
            Object lineCoordinates = objectHashMap.get("line_coordinates");
            Object orderNo = objectHashMap.get("orderNo");


            //区域表数据
            if (null != areaId) {
                String temp1 = "('" + areaId + "','" + areaName + "')";
                if (!areaListAll.contains(temp1)) {
                    areaListAll.add(temp1);
                    if (fimsAreaSqlValues.toString().equalsIgnoreCase("")) {
                        fimsAreaSqlValues = new StringBuilder(temp1);
                    } else {
                        if (!fimsAreaSqlValues.toString().contains(temp1)) {
                            fimsAreaSqlValues.append(",").append(temp1);
                        }
                    }
                }
            }

            //线路表数据
            if (null != lineId) {
                String temp2 = "('" + lineId + "','" + voltage + "','" + lineName + "','" + shortName + "','" + areaId + "')";
                if (!lineListAll.contains(lineId)) {
                    lineListAll.add(String.valueOf(lineId));
                    if (fimsLineSqlValues.toString().equalsIgnoreCase("")) {
                        fimsLineSqlValues = new StringBuilder(temp2);
                    } else {
                        if (!fimsLineSqlValues.toString().contains(temp2)) {
                            fimsLineSqlValues.append(",").append(temp2);
                        }
                    }
                }
            }

            //线路坐标数据表
            if (null != objId) {
                String temp3 = "('" + getUUID() + "','" + objId + "','" + gps + "','" + coordinateType + "')";
                if (!lineGpsListAll.contains(objId)) {
                    lineGpsListAll.add(String.valueOf(objId));
                    if (fimsGpsSqlValues.toString().equalsIgnoreCase("")) {
                        fimsGpsSqlValues = new StringBuilder(temp3);
                    } else {
                        if (!fimsGpsSqlValues.toString().contains(temp3)) {
                            fimsGpsSqlValues.append(",").append(temp3);
                        }
                    }
                }
            }

            //插入杆塔表
            if (null != poleId) {
                String temp4 = "('" + poleId + "','" + fpName + "','" + depict + "','" + baiduLng + "','" + baiduLat + "','" + isLine + "','" + lineCoordinates + "','" + lineId + "','" + orderNo + "')";
                if (fimsPoleSqlValues.toString().equalsIgnoreCase("")) {
                    fimsPoleSqlValues = new StringBuilder(temp4);
                } else {
                    if (!fimsPoleSqlValues.toString().contains(temp4)) {
                        fimsPoleSqlValues.append(",").append(temp4);
                    }

                }
            }
            //插入线路杆塔关联表
            if (null != poleId && null != lineId) {
                String temp5 = "('" + getUUID() + "','" + lineId + "','" + poleId + "')";
                if (fimsLinePoleSqlValues.toString().equalsIgnoreCase("")) {
                    fimsLinePoleSqlValues = new StringBuilder(temp5);
                } else {
                    if (!fimsLinePoleSqlValues.toString().contains(temp5)) {
                        fimsLinePoleSqlValues.append(",").append(temp5);
                    }
                }
            }

            //满1000 分批插入
            if (i % 1000 == 0) {
                insert(fimsAreaSqlValues.toString(), fimsLineSqlValues.toString(), fimsGpsSqlValues.toString(), fimsPoleSqlValues.toString(), fimsLinePoleSqlValues.toString());
                fimsAreaSqlValues = new StringBuilder();
                fimsLineSqlValues = new StringBuilder();
                fimsGpsSqlValues = new StringBuilder();
                fimsPoleSqlValues = new StringBuilder();
                fimsLinePoleSqlValues = new StringBuilder();

            }

            //最后插入
            if (i == size - 1) {
                //满1000插入
                if (i % 1000 == 0) {
                    insert(fimsAreaSqlValues.toString(), fimsLineSqlValues.toString(), fimsGpsSqlValues.toString(), fimsPoleSqlValues.toString(), fimsLinePoleSqlValues.toString());
                    fimsAreaSqlValues = new StringBuilder();
                    fimsLineSqlValues = new StringBuilder();
                    fimsGpsSqlValues = new StringBuilder();
                    fimsPoleSqlValues = new StringBuilder();
                    fimsLinePoleSqlValues = new StringBuilder();

                } else { //不满1000插入
                    insert(fimsAreaSqlValues.toString(), fimsLineSqlValues.toString(), fimsGpsSqlValues.toString(), fimsPoleSqlValues.toString(), fimsLinePoleSqlValues.toString());
                    fimsAreaSqlValues = new StringBuilder();
                    fimsLineSqlValues = new StringBuilder();
                    fimsGpsSqlValues = new StringBuilder();
                    fimsPoleSqlValues = new StringBuilder();
                    fimsLinePoleSqlValues = new StringBuilder();
                }
            }
        }
    }

    /**
     * 插入数据库
     */
    public void insert(String fimsAreaSqlValues, String fimsLineSqlValues, String fimsGpsSqlValues, String fimsPoleSqlValues, String fimsLinePoleSqlValues) {

        int andIncrement = atomicIntegerDB.getAndIncrement();
        System.out.println((andIncrement * 1000) + " 条 : " + new Date() + " 开始插入数据...");
        //插入区域表 fims_area   area_id,name
        String fimsAreaSql = "insert into fims_area (area_id,name) values " + fimsAreaSqlValues;

        //插入线路数据表 fims_line  ,line_id,voltage,name,short_name,area_id
        String fimsLineSql = "insert into fims_line (line_id,voltage,name,short_name,area_id) values " + fimsLineSqlValues;


        //线路坐标数据表 fims_gps id,obj_id,gps,coordinate_type=0
        String fimsGpsSql = "insert into fims_gps (id,obj_id,gps,coordinate_type) values " + fimsGpsSqlValues;

        //插入杆塔表 fims_pole  pole_id,fp_name,depict,baidu_lng,baidu_lat
        String fimsPoleSql = "insert into fims_pole (pole_id,fp_name,depict,baidu_lng,baidu_lat,is_line,line_coordinates,line_id,sort_no) values " + fimsPoleSqlValues;

        //插入线路杆塔关联表  fims_line_pole    id,line_id,pole_id
        String fimsLinePoleSql = "insert into fims_line_pole (id,line_id,pole_id) values" + fimsLinePoleSqlValues;


        try {
            //插入区域表
            connection.setAutoCommit(false);
            if (!fimsAreaSqlValues.equalsIgnoreCase("")) {
                connection.createStatement().execute(fimsAreaSql);
            }
            connection.commit();

        } catch (Exception throwables) {
            try {
                connection.rollback();
            } catch (Exception e) {
                System.out.println("回滚异常!");
                e.printStackTrace();
            }
            System.out.println("插入区域表 插入数据库错误: " + fimsAreaSql);
            throwables.printStackTrace();
        }

        try {
            //插入线路数据表
            connection.setAutoCommit(false);
            if (!fimsLineSqlValues.equalsIgnoreCase("")) {
                connection.createStatement().execute(fimsLineSql);
            }
            connection.commit();

        } catch (Exception throwables) {
            try {
                connection.rollback();
            } catch (Exception e) {
                System.out.println("回滚异常!");
                e.printStackTrace();
            }
            System.out.println("线路数据表 插入数据库错误: " + fimsLineSql);
            throwables.printStackTrace();
        }

        try {
            //线路坐标数据表
            connection.setAutoCommit(false);
            if (!fimsGpsSqlValues.equalsIgnoreCase("")) {
                connection.createStatement().execute(fimsGpsSql);
            }

            connection.commit();

        } catch (Exception throwables) {

            try {
                connection.rollback();
            } catch (Exception e) {
                System.out.println("回滚异常!");
                e.printStackTrace();
            }
            System.out.println("线路坐标数据表 插入数据库错误: " + fimsGpsSql);
            throwables.printStackTrace();
        }

        try {
            //插入杆塔表
            connection.setAutoCommit(false);
            if (!fimsPoleSqlValues.equalsIgnoreCase("")) {
                connection.createStatement().execute(fimsPoleSql);
            }

            connection.commit();

        } catch (Exception throwables) {

            try {
                connection.rollback();
            } catch (Exception e) {
                System.out.println("回滚异常!");
                e.printStackTrace();
            }
            System.out.println("杆塔表 插入数据库错误: " + fimsPoleSql);
            throwables.printStackTrace();
        }

        try {
            //插入线路杆塔关联表
            connection.setAutoCommit(false);
            if (!fimsLinePoleSqlValues.equalsIgnoreCase("")) {
                connection.createStatement().execute(fimsLinePoleSql);
            }
            connection.commit();

        } catch (Exception throwables) {

            try {
                connection.rollback();
            } catch (Exception e) {
                System.out.println("回滚异常!");
                e.printStackTrace();
            }
            System.out.println("线路杆塔关联表 插入数据库错误: " + fimsLinePoleSql);
            throwables.printStackTrace();
        }
    }

    /**
     * 找到电压等级
     */
    private void setAreavoltage(String dirStr) {
        if (dirStr.contains("广东_惠州_110_C诚滨乙线-2T江畔乙支线（电缆）.kml")) {
            System.out.println("");
        }
        if (dirStr.contains(",")) {
            String[] split = dirStr.split(",");
            StringBuilder areaName = new StringBuilder();
            String voltageLevel = "";
            for (int i = 0; i < split.length; i++) {
                String value = split[i];
                if (!"线路路径".equalsIgnoreCase(value)) {
                    try {
                        String number = value.toLowerCase().split("kv")[0];
                        Integer.parseInt(number);
                        voltageLevel = number + "kV";
                    } catch (Exception e) {
                        if (i == 1) {
                            areaName = new StringBuilder(value);
                        }
                    }
                }
            }
            HashMap<String, String> map = new HashMap<>();
            String name = areaName.toString();
            if (name.contains("片区")) {
                if (name.contains("-")) {
                    name = name.split("-")[0];
                }
            }

            map.put(name, voltageLevel);
            areaVoMap.put(dirStr, map);
        }


    }

    /**
     * 获取区域ID
     */
    public String getAreaId(String name) {
        Object o = areaIdMap.get(name);
        if (null == o) {
            String uuid = getUUID();
            areaIdMap.put(name, uuid);
            return uuid;
        }
        return null;
    }

    /**
     * 获取线路ID
     */
    public String getLineId(String name) {
        Object o = lineIdMap.get(name);
        if (null == o) {
            String uuid = getUUID();
            lineIdMap.put(name, uuid);
            return uuid;
        }
        return null;
    }

    /**
     * 查询区域ID,设置区域ID
     */
    public void setAreaIdMap() {
        String querySql = "SELECT  area_id,NAME FROM  fims_area WHERE NAME IN (SELECT  DISTINCT(NAME) FROM fims_area GROUP BY NAME)";
        try {
            ResultSet resultSet = connection.createStatement().executeQuery(querySql);
            while (resultSet.next()) {
                String areaId = resultSet.getString("area_id");
                String name = resultSet.getString("NAME");
                areaIdMap.put(name, areaId);
            }
            System.out.println("查询区域数据完成!");
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * 查询线路ID,设置线路ID
     */
    public void setLineIdMap() {
        String querySql = "SELECT  line_id,NAME FROM  fims_line WHERE NAME IN (SELECT  DISTINCT(NAME) FROM fims_line GROUP BY NAME)";

        try {
            ResultSet resultSet = connection.createStatement().executeQuery(querySql);
            while (resultSet.next()) {
                String lineId = resultSet.getString("line_id");
                String name = resultSet.getString("NAME");
                areaIdMap.put(name, lineId);
            }
            System.out.println("查询线路数据完成!");
        } catch (Exception throwables) {
            throwables.printStackTrace();
        }
    }

    /**获取ID*/
    public String getUUID() {

        int andIncrement = atomicInteger.getAndIncrement();
        int andIncrement2 = atomicInteger.getAndIncrement();

        double ranNumber = Math.random() * 10000000000L;

        String currentTimeMillis = System.currentTimeMillis() + "";
        String ranNumber2 = Math.random() * 10000000000L + "";

        String toString = UUID.randomUUID().toString();

        String id = andIncrement + andIncrement2 + ranNumber + currentTimeMillis + ranNumber2 + toString;

        return id.replaceAll("\\.", "").substring(0, 32);

    }

}
