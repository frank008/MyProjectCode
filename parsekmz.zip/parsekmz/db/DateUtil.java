package com.dfdk.common.utils.parseUtils.parsekmz.db;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

/**
 * 时间工具类
 *

 */
public class DateUtil {

    public static final String FULL_TIME_PATTERN = "yyyyMMddHHmmss";

    public static final String FULL_TIME_SPLIT_PATTERN = "yyyy-MM-dd HH:mm:ss";

    public static final String CST_TIME_PATTERN = "EEE MMM dd HH:mm:ss zzz yyyy";

    public static String formatFullTime(LocalDateTime localDateTime) {
        return formatFullTime(localDateTime, FULL_TIME_PATTERN);
    }

    public static String formatFullTime(LocalDateTime localDateTime, String pattern) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(pattern);
        return localDateTime.format(dateTimeFormatter);
    }

    public static String getDateFormat(Date date, String dateFormatType) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormatType, Locale.CHINA);
        return simpleDateFormat.format(date);
    }

    public static String formatCstTime(String date, String format) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(CST_TIME_PATTERN, Locale.US);
        Date usDate = simpleDateFormat.parse(date);
        return getDateFormat(usDate, format);
    }

    public static String formatInstant(Instant instant, String format) {
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        return localDateTime.format(DateTimeFormatter.ofPattern(format));
    }

    //计算时间差
    public static   String  getLocalDateTimeBetwenStartToEnd(LocalDateTime  startTime,LocalDateTime  endTime){
        String time="";

        if(endTime==null){
            endTime=LocalDateTime.now();
        }
        Duration betweenTime = Duration.between(startTime,endTime);

        Integer seconds= (int) betweenTime.getSeconds();
        Integer hour = seconds / 60 / 60;
        if(String.valueOf(hour).length()==1){
            time=time+"0"+hour;
        }else {
            time=time+hour;
        }

        Integer minutes = seconds / 60 % 60;
        if(String.valueOf(minutes).length()==1){
            time=time+":0"+minutes;
        }else {
            time=time+":"+minutes;
        }
        Integer remainingSeconds = seconds % 60;
        if(String.valueOf(remainingSeconds).length()==1){
            time=time+":0"+remainingSeconds;
        }else {
            time=time+":"+remainingSeconds;
        }
        return time;
    }
    //计算时间差 获得分钟
    public static   int  getLocalDateTimeBetwenMinutes(LocalDateTime  startTime){

        LocalDateTime  endTime=LocalDateTime.now();

        Duration betweenTime = Duration.between(startTime,endTime);

        Integer seconds= (int) betweenTime.getSeconds();

        Integer minutes = seconds / 60 % 60;
       return minutes;
    }
}
