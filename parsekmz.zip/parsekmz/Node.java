package com.dfdk.common.utils.parseUtils.parsekmz;

import de.micromata.opengis.kml.v_2_2_0.Placemark;

import java.util.ArrayList;
import java.util.List;

public class Node {

    //序号
    public int orderNo = 0;
    //节点名称
    public String name = "根节点";
    //根节点
    public Node rootNode;
    //父节点
    public Node parentNode;
    //子节点列表
    public List<Node> childrenNodes;

    public Node currentNode;

    public Placemark placemark;

    //初始化 当前节点 是它本身
    public Node() {
        this.childrenNodes=new ArrayList<>();
        this.currentNode = this;
    }


    //查看节点是否存在 存在则设为当前节点
    public void findNode(Node node, Node compareNode) {
        if (isEqualNode(node, compareNode)) {
            this.currentNode = node;
            return;
        }
        if (null != node.rootNode) {
            if (isEqualNode(node.rootNode, compareNode)) {
                this.currentNode = node.rootNode;
                return;
            }
        }
        if (null != node.parentNode) {
            if (isEqualNode(node.parentNode, compareNode)) {
                this.currentNode = node.parentNode;
                return;
            }
        }
        List<Node> childrenNodes = node.childrenNodes;
        if (null != childrenNodes) {
            if (childrenNodes.size() > 0) {
                for (int i = 0; i < childrenNodes.size(); i++) {
                    Node node1 = childrenNodes.get(i);
                    findNode(node1, compareNode);
                }
            }
        }

    }

    //判断两个node 是否相等
    public boolean isEqualNode(Node fromNode, Node toNode) {
        //序号 名称 父名称都相同
        if (fromNode.orderNo == toNode.orderNo && fromNode.name.equals(toNode.name)) {

            if (null != fromNode.parentNode && null != toNode.parentNode) {
                if (fromNode.parentNode.name.equalsIgnoreCase(toNode.parentNode.name)) {
                    return true;
                }
            }else {
                return true;
            }
        }
        return false;
    }


    //添加子节点
    public void addChildrenNode(Node currentNode, Node childNode) {
        if (!isEqualNode(currentNode, childNode)) {
            boolean isExit = false;
            if (null == currentNode.childrenNodes) {
                currentNode.childrenNodes = new ArrayList<>();
            }
            //判断节点是否存在于子节点中
            List<Node> childrenNodes = currentNode.childrenNodes;
            for (int i = 0; i < childrenNodes.size(); i++) {
                Node node = childrenNodes.get(i);
                if (isEqualNode(node, childNode)) {
                    isExit = true;
                }
            }
            //不存在子节点里面 则添加
            if (!isExit) {
                //父节点
                childNode.parentNode = currentNode;
                childrenNodes.add(childNode);
            }
        }
    }

    //添加节点 坐标点
    public void addNodePonit(Node currentNode, Node childNode, Placemark placemarkData) {
        if (isEqualNode(currentNode, childNode)) {
            currentNode.placemark = placemarkData;
            return;
        }
        if (!isEqualNode(currentNode, childNode)) {
            if (null == currentNode.childrenNodes) {
                currentNode.childrenNodes = new ArrayList<>();
            }
            //判断节点是否存在于子节点中
            List<Node> childrenNodes = currentNode.childrenNodes;
            for (int i = 0; i < childrenNodes.size(); i++) {
                Node node = childrenNodes.get(i);
                if (isEqualNode(node, childNode)) {
                    node.placemark = placemarkData;
                    break;
                }
            }
        }
    }


    public static void main(String[] args) {
        Node mainNode = new Node();
        Node node = new Node();
        node.name = "父节点001";

        mainNode.parentNode = node;
        mainNode.rootNode = node;


        //添加子节点
        for (int i = 0; i < 10; i++) {
            node = new Node();
            String name = i + "号-子节点";
            node.name = name;

            mainNode.findNode(mainNode, node);

            mainNode.addChildrenNode(mainNode.currentNode, node);
        }


        System.out.println("添加完成!");


    }

}