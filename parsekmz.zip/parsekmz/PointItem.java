package com.dfdk.common.utils.parseUtils.parsekmz;

import de.micromata.opengis.kml.v_2_2_0.Coordinate;

import java.util.ArrayList;
import java.util.List;

public class PointItem {

    public String name; //名称
    public String des; //描述

    public String parentName; //父类名称

    public ArrayList<String> dirList = new ArrayList<>(); //目录列表

    public List<Coordinate> pointsList = new ArrayList<>(); //线路列表 坐标 ，Coordinate 坐标对象

    public boolean isLine=false; //是否是线路

    //倒排序
    public void setDirListOrder() {
        ArrayList<String> dirList = this.dirList;
        ArrayList<String> tempList = new ArrayList<>();
        for (int i = 0; i < dirList.size(); i++) {
            int j = dirList.size() - 1 - i;
            String item = dirList.get(j);
            tempList.add(item);
        }
        this.dirList = tempList;
    }

    @Override
    public String toString() {
        return "PointItem{" +
                "name='" + name + '\'' +
                ", des='" + des + '\'' +
                ", parentName='" + parentName + '\'' +
                ", dirList=" + dirList +
                ", pointsList=" + pointsList +
                ", isLine=" + isLine +
                '}';
    }
}
